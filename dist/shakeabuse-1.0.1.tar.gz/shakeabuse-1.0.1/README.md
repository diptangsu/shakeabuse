# Shakeabuse

A simple command line app to display a shakespearean abuse on the console

