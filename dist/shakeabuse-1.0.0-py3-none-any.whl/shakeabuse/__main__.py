print('ABUSE')
